import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadproduct',
  templateUrl: './uploadproduct.component.html',
  styleUrls: ['./uploadproduct.component.css']
})
export class UploadproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
